package solucao.paulojunior;

public interface AreaCalculavel {
	
	double calculaArea();

}
